"""
Rule-based Customer Support Chatbot
Run: python chatbot.py
"""

import json
import re
from pathlib import Path
from datetime import datetime

BASE_DIR = Path(__file__).resolve().parent
FAQ_FILE = BASE_DIR / "data" / "faq.json"


def normalize(text):
    """Convert input to lowercase and remove extra whitespace."""
    return re.sub(r"\s+", " ", text.strip().lower())


def load_faq(path=FAQ_FILE):
    """Load FAQ data safely from JSON."""
    try:
        with open(path, "r", encoding="utf-8") as file:
            data = json.load(file)
        if not isinstance(data, dict):
            raise ValueError("FAQ data must be a JSON object.")
        return data
    except FileNotFoundError:
        print(f"Warning: FAQ file not found at {path}. Using built-in defaults.")
    except (json.JSONDecodeError, ValueError) as error:
        print(f"Warning: Could not read FAQ data ({error}). Using built-in defaults.")

    return {
        "business_hours": {
            "keywords": ["hours", "open", "close", "timing", "working hours"],
            "patterns": [r"\bwhen are you open\b", r"\bwhat time do you close\b"],
            "response": "Our support team is available Monday to Friday, 9:00 AM to 6:00 PM."
        },
        "shipping": {
            "keywords": ["shipping", "delivery", "deliver", "shipment"],
            "patterns": [r"\bwhere is my order\b", r"\bdelivery time\b"],
            "response": "Standard delivery usually takes 3–5 business days."
        }
    }


def find_intents(user_text, faq):
    """Return every FAQ intent matched by keywords or regular expressions."""
    text = normalize(user_text)
    matches = []

    for intent_name, details in faq.items():
        keywords = details.get("keywords", [])
        patterns = details.get("patterns", [])
        keyword_match = any(
            re.search(r"\b" + re.escape(normalize(keyword)) + r"\b", text)
            for keyword in keywords
        )
        regex_match = any(re.search(pattern, text, re.IGNORECASE) for pattern in patterns)

        if keyword_match or regex_match:
            matches.append(intent_name)

    return matches


def build_response(user_text, faq):
    """Create a contextual response; support multiple intents in one message."""
    intents = find_intents(user_text, faq)

    if not intents:
        return (
            "I'm sorry, I didn't understand that question. "
            "You can ask about business hours, products, payment, returns, or delivery."
        )

    responses = []
    for intent in intents:
        response = faq[intent].get("response", "I don't have an answer for that yet.")
        responses.append(response)

    if len(responses) == 1:
        return responses[0]

    return "I found answers to a few things:\n" + "\n".join(
        f"- {response}" for response in responses
    )


def is_exit_command(user_text):
    """Recognize clean exit commands, including punctuation."""
    return bool(re.fullmatch(r"(bye|exit|quit|goodbye)[.! ]*", normalize(user_text)))


def is_greeting(user_text):
    """Recognize common greetings as complete words."""
    text = normalize(user_text)
    return bool(re.search(r"\b(hi|hello|hey|good morning|good afternoon)\b", text))


def run_chatbot():
    faq = load_faq()
    print("=" * 58)
    print("Welcome to HelpDesk Bot!")
    print("Ask me about our business hours, products, payments,")
    print("returns, or delivery. Type 'bye', 'exit', or 'quit' to leave.")
    print("=" * 58)

    while True:
        try:
            user_text = input("\nYou: ")
        except (EOFError, KeyboardInterrupt):
            print("\nBot: Session ended. Thank you for chatting with us!")
            break

        if not user_text.strip():
            print("Bot: Please type a question so I can help.")
            continue

        if is_exit_command(user_text):
            print("Bot: Goodbye! Thank you for contacting HelpDesk.")
            break

        if is_greeting(user_text):
            print("Bot: Hello! How can I help you today?")
            continue

        print("Bot:", build_response(user_text, faq))


if __name__ == "__main__":
    run_chatbot()
