import unittest
from pathlib import Path
import sys

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import chatbot


class ChatbotTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.faq = chatbot.load_faq()

    def test_normalize(self):
        self.assertEqual(chatbot.normalize("  HELLO   THERE "), "hello there")

    def test_business_hours_keyword(self):
        self.assertIn("Monday to Friday", chatbot.build_response("What are your hours?", self.faq))

    def test_regex_match(self):
        self.assertIn("3–5 business days", chatbot.build_response("Where is my order?", self.faq))

    def test_multi_intent(self):
        answer = chatbot.build_response("Tell me about payment and returns", self.faq)
        self.assertIn("debit cards", answer)
        self.assertIn("returned within 7 days", answer)

    def test_fallback(self):
        self.assertIn("didn't understand", chatbot.build_response("What is the moon made of?", self.faq))

    def test_exit_commands(self):
        for command in ("bye", "exit", "quit", "goodbye!"):
            self.assertTrue(chatbot.is_exit_command(command))

    def test_not_exit_inside_sentence(self):
        self.assertFalse(chatbot.is_exit_command("I will not exit now"))

    def test_greeting(self):
        self.assertTrue(chatbot.is_greeting("Hello there"))

if __name__ == "__main__":
    unittest.main()
