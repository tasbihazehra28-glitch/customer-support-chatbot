# Rule-Based Customer Support Chatbot

A beginner-friendly Python chatbot that answers common customer-support questions using keyword matching and regular expressions.

## Features

- Normalizes input (lowercase and removes extra whitespace).
- Detects intents using keywords and regular expressions (`re`).
- Supports multiple intents in one message.
- Answers questions about business hours, products, payment, returns, delivery, and support contact.
- Provides a helpful fallback when no intent is recognized.
- Handles greetings, blank input, and clean exit commands (`bye`, `exit`, `quit`, `goodbye`).
- Loads FAQ responses from a separate JSON dataset.
- Handles a missing or invalid JSON file gracefully.
- Handles Ctrl+C and end-of-input without an unhandled error.

## Requirements

- Python 3.8 or newer
- No third-party packages are required.

## Project structure

```text
customer_support_chatbot/
├── chatbot.py
├── data/
│   └── faq.json
├── tests/
│   └── test_chatbot.py
├── sample_conversation.txt
├── .gitignore
└── README.md
```

## Run the chatbot

1. Download and extract the ZIP file.
2. Open a terminal in the extracted `customer_support_chatbot` folder.
3. Run:

   ```bash
   python chatbot.py
   ```

   On some systems, use `python3 chatbot.py`.

4. Try questions such as:
   - `Hello`
   - `What are your business hours?`
   - `How can I pay by card?`
   - `What is your return policy?`
   - `How long does delivery take?`
   - `Tell me about your products and payment methods`
   - `Do you provide international shipping?`
5. Type `bye` to end the conversation.

## Run tests

From the project folder:

```bash
python -m unittest discover -s tests -v
```

## How it works

1. **Input:** The user enters a question.
2. **Normalization:** The `normalize()` function converts text to lowercase and removes extra spaces.
3. **Intent matching:** `find_intents()` checks the message against each FAQ entry's keywords and regex patterns.
4. **Response generation:** `build_response()` returns the matching answer or a fallback response. If more than one intent matches, all relevant answers are returned.
5. **Exit handling:** `is_exit_command()` checks for `bye`, `exit`, `quit`, or `goodbye`.
6. **Error handling:** `load_faq()` uses built-in defaults if the JSON file is missing or invalid.

## Customize the FAQ

Edit `data/faq.json`. Each intent should contain:
- `keywords`: a list of words or phrases to match.
- `patterns`: a list of regular expressions.
- `response`: the chatbot's answer.

Example:

```json
{
  "store_location": {
    "keywords": ["address", "location"],
    "patterns": ["\\bwhere are you located\\b"],
    "response": "Our main store is in the city centre."
  }
}
```

## GitHub upload

1. Sign in to GitHub and create a **New repository**.
2. Give it a name such as `customer-support-chatbot`.
3. Keep it **Public** if the task provider needs to view it.
4. Upload the extracted project files (or use Git).
5. Click **Commit changes**.
6. Open the repository page and copy its URL. Submit that URL wherever the task platform asks for the GitHub link.

Example repository URL format: `https://github.com/YOUR-USERNAME/customer-support-chatbot`

## Important

This is a completed starter project for the stated task. Before submitting, run the chatbot and tests, check your course/platform's exact submission rules, and replace the sample support email/phone number with real details only if your assignment requires them. A GitHub upload alone does not guarantee a certificate; certificate eligibility depends on the issuing platform's requirements.
